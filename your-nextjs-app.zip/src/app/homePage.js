// pages/index.js
import React from 'react';


const HomePage = () => {
    return (
      <div className="bg-white">
       <div className="relative isolate px-6 lg:px-8">
        {/* <div
          className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
          aria-hidden="true"
        >
          <div
            className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
          />
        </div> */}
        <div className="mx-auto max-w-3xl py-32 sm:py-48 lg:py-20">
         
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </h1>
            <p className="mt-6 text-sm leading-6 text-gray-600">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
            Vivamus rutrum, quam ut volutpat commodo, sapien metus convallis erat, cursus suscipit neque eros quis nisl. Donec non fringilla diam, non porta elit. 
            </p>
            <div className="flex max-w-md gap-x-1 Newsletter">
              <label htmlFor="email-address" className="sr-only">
                Email address
              </label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="border min-w-0 flex-auto rounded-md bg-white/5 px-3.5 py-2 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500 sm:text-sm sm:leading-6"
                placeholder="Enter your email"
              />
              <button
                type="submit"
                className="flex-none rounded-md bg-indigo-500 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
              >
                Subscribe
              </button>
            </div>
          
            {/* <div className="mt-10 flex items-center justify-center gap-x-6">
              <a
                href="#"
                className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Get started
              </a>
              <a href="#" className="text-sm font-semibold leading-6 text-gray-900">
                Learn more <span aria-hidden="true">→</span>
              </a>
            </div> */}
          </div>
            
        </div>
        <div className="max-w-7xl mC">
        <div class="grid grid-cols-5 bg-gray-300">
            <div class="bg-gray-300 p-4 text-center">
              
            <img class="h-auto rounded-lg p-5" 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Heraldic_shield_placeholder.png/436px-Heraldic_shield_placeholder.png" alt="image description" />

              </div>
              <div class="bg-gray-300 p-4 text-center"><img class=" p-5 h-auto rounded-lg" 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Heraldic_shield_placeholder.png/436px-Heraldic_shield_placeholder.png" alt="image description" />
</div>
              <div class="bg-gray-300 p-4 text-center"><img class=" p-5 h-auto rounded-lg" 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Heraldic_shield_placeholder.png/436px-Heraldic_shield_placeholder.png" alt="image description" />
</div>
              <div class="bg-gray-300 p-4 text-center"><img class="p-5 h-auto rounded-lg" 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Heraldic_shield_placeholder.png/436px-Heraldic_shield_placeholder.png" alt="image description" />
</div>
              <div class="bg-gray-300 p-4 text-center">
                <img class="h-auto rounded-lg p-5" 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Heraldic_shield_placeholder.png/436px-Heraldic_shield_placeholder.png" alt="image description" />
</div>

            <p>COMPANY ACHIEVEMENT</p>
            </div>
        </div><br /><br /><br /><br />
        
        
        {/* <div
          className="absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]"
          aria-hidden="true"
        >
          <div
            className="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
          />
        </div> */}
      </div>
      {/* Feature Section  */}
        <div>

        </div>
      </div>

    
    );
  };
  
  export default HomePage;
  