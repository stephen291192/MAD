import React from "react";

const Team = () => {
    return (
      <div>
        <h1>Team Page</h1>
        <p>This is the about page of our Next.js app.</p>
      </div>
    );
  };
  
  export default Team;